from __future__ import annotations
import numpy as np
import time
import torch

from transformers.modeling_outputs import BaseModelOutput

class STTPipeline:
    def __init__(
        self,
        use_hailo: bool,
        hef_path: str,
        window_seconds: int,
        decoder_local_dir: str | None
    ):
        self.use_hailo = use_hailo
        self.hef_path = hef_path
        self.window_seconds = window_seconds
        self.decoder_local_dir = decoder_local_dir

        self.hailo_enc = None
        self.hf_processor = None
        self.hf_decoder = None
        self.fw_model = None  # fallback faster-whisper
        self._init_models()

    def _init_models(self):
        try:
            if self.use_hailo:
                from hailo_whisper import HailoWhisperEncoder
                from transformers import WhisperForConditionalGeneration, AutoProcessor
                self.hailo_enc = HailoWhisperEncoder(self.hef_path, float_output=True)
                if self.decoder_local_dir:
                    from transformers import AutoProcessor as _AP, WhisperForConditionalGeneration as _W
                    self.hf_processor = _AP.from_pretrained(self.decoder_local_dir)
                    self.hf_decoder = _W.from_pretrained(self.decoder_local_dir).eval().to("cpu")
                else:
                    self.hf_processor = AutoProcessor.from_pretrained("openai/whisper-base")
                    self.hf_decoder = WhisperForConditionalGeneration.from_pretrained("openai/whisper-base").eval().to("cpu")
                print("STT siap: Hailo encoder (base, 5s) + HF decoder (CPU).")
            else:
                raise RuntimeError("USE_HAILO_ENCODER is False")
        except Exception as e:
            print(f"Gagal init Hailo encoder pipeline: {e}. Fallback ke faster-whisper.")
            try:
                from faster_whisper import WhisperModel
                self.fw_model = WhisperModel("base", device="cpu", compute_type="int8")
                print("Model STT (faster-whisper 'base') berhasil dimuat.")
            except Exception as e2:
                print(f"Gagal memuat model STT (faster-whisper): {e2}")
                raise

    def _fit_to_hailo_window(self, feats_np: np.ndarray, window_seconds: int) -> np.ndarray:
        target_T = int(3000 * window_seconds / 30)  # e.g. 5s -> 500
        T = feats_np.shape[2]
        if T == target_T:
            return feats_np
        if T > target_T:
            return feats_np[:, :, :target_T]
        pad = np.zeros((1, 80, target_T - T), dtype=feats_np.dtype)
        return np.concatenate([feats_np, pad], axis=2)

    def transcribe(self, audio_array_float32, sampling_rate=16000, language="Indonesian"):
        # Prefer Hailo
        if self.hailo_enc is not None and self.hf_processor is not None and self.hf_decoder is not None:
            try:
                if audio_array_float32.size == 0:
                    return {'text': '', 'processing_time': 0}
                start = time.time()
                inputs = self.hf_processor(audio_array_float32, sampling_rate=sampling_rate, return_tensors="np")
                feats = inputs["input_features"].astype(np.float32)
                feats = self._fit_to_hailo_window(feats, self.window_seconds)
                enc_np = self.hailo_enc.encode(feats)
                enc_t = torch.from_numpy(enc_np).to("cpu")
                enc_out = BaseModelOutput(last_hidden_state=enc_t)
                lang_map = {"Indonesian": "indonesian", "English": "english", "Japanese": "japanese"}
                lang_name = lang_map.get(language, "indonesian")
                forced_ids = self.hf_processor.get_decoder_prompt_ids(language=lang_name, task="transcribe")
                with torch.no_grad():
                    gen_ids = self.hf_decoder.generate(
                        encoder_outputs=enc_out,
                        forced_decoder_ids=forced_ids,
                        max_new_tokens=96,
                        num_beams=1
                    )
                from transformers import AutoProcessor  # type: ignore  # for mypy
                text = self.hf_processor.batch_decode(gen_ids, skip_special_tokens=True)[0].strip()
                return {'text': text, 'processing_time': time.time() - start}
            except Exception as e:
                print(f"Error Hailo path: {e}")

        # Fallback
        if self.fw_model is None or audio_array_float32.size == 0:
            return {'text': '', 'processing_time': 0}
        try:
            start = time.time()
            lang_code_map = {"Indonesian": "id", "English": "en", "Japanese": "ja"}
            fw_lang_code = lang_code_map.get(language, "id")
            if audio_array_float32.dtype != np.float32:
                audio_array_float32 = audio_array_float32.astype(np.float32)
            segments, info = self.fw_model.transcribe(
                audio_array_float32, beam_size=5, language=fw_lang_code, vad_filter=True
            )
            text = "".join(s.text for s in segments).strip()
            return {'text': text, 'processing_time': time.time() - start}
        except Exception as e:
            print(f"Error faster-whisper: {e}")
            return {'text': '', 'processing_time': 0}

    def close(self):
        try:
            if self.hailo_enc is not None:
                self.hailo_enc.close()
                print("Hailo encoder ditutup.")
        except Exception:
            pass
