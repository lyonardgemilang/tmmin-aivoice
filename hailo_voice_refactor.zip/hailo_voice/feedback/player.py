from __future__ import annotations
import os, time, pygame
from dataclasses import dataclass

@dataclass
class FeedbackContext:
    base_feedback_dir: str
    gender: str
    language: str

class FeedbackPlayer:
    def __init__(self, feedback_base_dir: str, main_loop_event):
        self.base_dir = feedback_base_dir
        self.main_loop_event = main_loop_event
        try:
            pygame.mixer.init()
        except pygame.error as e:
            print(f"Gagal inisialisasi pygame mixer: {e}. Feedback suara mungkin tidak berfungsi.")

    def _play_blocking(self, file_path: str):
        if not os.path.exists(file_path):
            print(f"File audio feedback tidak ditemukan: {file_path}")
            return
        try:
            if pygame.mixer.music.get_busy():
                pygame.mixer.music.stop()
                pygame.mixer.music.unload()
                time.sleep(0.05)
            pygame.mixer.music.load(file_path)
            pygame.mixer.music.play()
            while pygame.mixer.music.get_busy() and self.main_loop_event.is_set():
                time.sleep(0.05)
            if not self.main_loop_event.is_set():
                pygame.mixer.music.stop()
        except pygame.error as e:
            print(f"Gagal memainkan file audio '{file_path}': {e}")
        except Exception as e:
            print(f"Error tak terduga saat memainkan audio: {e}")

    def ping_speak(self):
        self._play_blocking(os.path.join(self.base_dir, "ping_berbicara.mp3"))

    def off_to_wake(self):
        self._play_blocking(os.path.join(self.base_dir, "off_to_wakeword.mp3"))

    def system_on(self):
        self._play_blocking(os.path.join(self.base_dir, "system_on.mp3"))

    def speak_prompt(self, language: str, gender: str, name: str):
        lang_path = os.path.join(self.base_dir, language)
        if not os.path.isdir(lang_path):
            print(f"Peringatan: Direktori feedback audio '{language}' tidak ditemukan. Fallback ke 'Indonesian'.")
            lang_path = os.path.join(self.base_dir, "Indonesian")
            if not os.path.isdir(lang_path):
                print(f"Peringatan: Direktori feedback audio default 'Indonesian' juga tidak ditemukan.")
                return
        suffix = "_pria" if gender == "pria" else ""
        self._play_blocking(os.path.join(lang_path, f"{name}{suffix}.mp3"))

    def close(self):
        try:
            if pygame.mixer.get_init():
                pygame.mixer.music.stop()
                pygame.mixer.quit()
                print("Pygame mixer dihentikan.")
        except Exception:
            pass
