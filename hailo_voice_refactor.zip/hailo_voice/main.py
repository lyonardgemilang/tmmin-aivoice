from .app import MainApp

def main():
    app = MainApp(using_esp=False)  # set True if you want to control ESP32
    app.run()

if __name__ == "__main__":
    main()
