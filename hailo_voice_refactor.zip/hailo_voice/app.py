from __future__ import annotations
import os, threading, time, numpy as np, speech_recognition as sr

import sounddevice as sd

from .config import Config
from .state import ProgramState
from .audio.buffer import AudioRingBuffer
from .audio.io import check_microphones, check_speakers, record_audio, is_audio_present
from .devices.esp import ESP32Client
from .network.web_client import WebServerClient
from .network.net import is_internet_connected
from .stt.stt_pipeline import STTPipeline
from .nlp.intent import IntentClassifier
from .wake.wake_detector import WakeWordDetector
from .feedback.player import FeedbackPlayer

class MainApp:
    def __init__(self, using_esp: bool = False):
        self.cfg = Config()
        self.state = ProgramState()
        self.using_esp = using_esp

        self.esp = ESP32Client(using_esp=using_esp)
        self.web_client = WebServerClient(self.cfg.SEND_TO_WEBSERVER, self.cfg.WEB_SERVER_URL)
        self.stt = STTPipeline(
            use_hailo=self.cfg.USE_HAILO_ENCODER,
            hef_path=self.cfg.HAILO_ENCODER_HEF,
            window_seconds=self.cfg.HAILO_WINDOW_SECONDS,
            decoder_local_dir=self.cfg.DECODER_LOCAL_DIR,
        )
        self.intent = IntentClassifier(base_dir=os.path.dirname(os.path.abspath(__file__)))
        self.feedback = FeedbackPlayer(self.cfg.FEEDBACK_DIR, None)  # set main_loop later

        self.main_loop_active_flag = threading.Event()
        self.main_loop_active_flag.set()
        self.feedback.main_loop_event = self.main_loop_active_flag

        self.ring = AudioRingBuffer(self.cfg.BUFFER_SIZE_BYTES)
        self.audio_stream = None
        self.active_command_threads: list[threading.Thread] = []

    # ===== Feedback & Actions =====
    def _send_to_esp(self, cmd: str) -> bool:
        return self.esp.send(cmd)

    def _intent_feedback(self, intent: str, predicted_language="Indonesian"):
        if intent == self.state.last_command and intent not in ["wake", "off", "system_on"]:
            print(f"Intent '{intent}' sudah dieksekusi sebelumnya dan bukan wake/off/system_on. Mengabaikan feedback audio & ESP.")
            return

        colors = ["merah", "hijau", "biru", "lavender", "magenta", "pink", "violet", "aqua", "kuning", "emas", "abu"]
        audio_to_play = None

        original_last_command = self.state.last_command

        if "nyalakan lampu" in intent:
            real_color = None
            for c in colors:
                if c in intent.lower():
                    real_color = c
                    break
            if real_color:
                if self._send_to_esp(real_color.upper()):
                    self.feedback.speak_prompt(predicted_language, self.state.gender, "ganti_warna")
                    self.state.current_light_state = real_color.upper()
                    self.state.last_command = intent
            elif intent == "nyalakan lampu":
                if self._send_to_esp("ON"):
                    self.feedback.speak_prompt(predicted_language, self.state.gender, "menyalakan_lampu")
                    self.state.current_light_state = "ON"
                    self.state.last_command = intent
        elif "matikan lampu" in intent:
            if self._send_to_esp("OFF"):
                self.feedback.speak_prompt(predicted_language, self.state.gender, "mematikan_lampu")
                self.state.current_light_state = "OFF"
                self.state.last_command = intent
        elif "nyalakan mode senang" in intent:
            if self._send_to_esp("HAPPY"):
                self.feedback.speak_prompt(predicted_language, self.state.gender, "senang")
                self.state.last_command = intent
        elif "nyalakan mode sad" in intent:
            if self._send_to_esp("SAD"):
                self.feedback.speak_prompt(predicted_language, self.state.gender, "sedih")
                self.state.last_command = intent
        elif "gender ke wanita" in intent:
            self.state.gender = "wanita"
            self.feedback.speak_prompt(predicted_language, self.state.gender, "ganti_suara_ke_wanita")
            print("Gender diubah ke wanita.")
            self.state.last_command = intent
        elif "gender ke pria" in intent:
            self.state.gender = "pria"
            self.feedback.speak_prompt(predicted_language, self.state.gender, "ganti_suara_ke_pria")
            print("Gender diubah ke pria.")
            self.state.last_command = intent
        elif "fitur belum didukung" in intent:
            self.feedback.speak_prompt(predicted_language, self.state.gender, "fitur_belum_didukung")
            self.state.last_command = intent
        elif intent in self.intent.NEW_ONLINE_ONLY_LABELS:
            print(f"Fitur terdeteksi tapi belum ada feedback audio untuk intent '{intent}'.")
            self.web_client.send_label(intent)
            self.state.last_command = intent
        elif "wake" in intent:
            self.feedback.ping_speak()
            self.feedback.speak_prompt(predicted_language, self.state.gender, "berbicara")
            self.state.last_command = intent
        elif "off" in intent:
            self.feedback.off_to_wake()
            self.state.last_command = intent
        elif "system_on" in intent:
            self.feedback.system_on()
            self.state.last_command = intent
        elif "turunkan kecerahan" in intent:
            if self._send_to_esp("turunkan brightness"):
                self.feedback.speak_prompt(predicted_language, self.state.gender, "turunkan_kecerahan")
                self.state.last_command = intent
        elif "naikkan kecerahan" in intent:
            if self._send_to_esp("naikkan brightness"):
                self.feedback.speak_prompt(predicted_language, self.state.gender, "naikkan_kecerahan")
                self.state.last_command = intent
        elif "tidak relevan" in intent:
            print("Perintah tidak dikenali atau tidak ada suara signifikan.")

    # ===== Initialization =====
    def initialize_system(self) -> bool:
        print("Inisialisasi sistem...")
        self.state.last_command = "system_booting"
        if self.using_esp:
            self.esp.connect()
        else:
            print("Mode tanpa ESP32 diaktifkan.")

        try:
            # Wake model path/name from original
            vosk_name = "vosk-model-en-us-0.22-lgraph"
            self.wake = WakeWordDetector(
                vosk_model_path_or_name=os.path.join(os.path.dirname(os.path.abspath(__file__)), "vosk_models", vosk_name),
                samplerate=self.cfg.DEFAULT_SAMPLE_RATE
            )
        except Exception as e:
            print(f"FATAL: {e}. Program berhenti.")
            return False

        if not check_microphones():
            print("PERINGATAN PENTING: Mikrofon yang sesuai tidak terdeteksi atau tidak ada default.")
        check_speakers()
        self._intent_feedback("system_on")
        print("Sistem siap.")
        return True

    # ===== Callbacks =====
    def _sd_callback(self, indata, frames, time_info, status):
        if status and status.input_overflow:
            print("PERINGATAN: Input audio overflow! Data audio mungkin hilang.")
        self.ring.write(bytes(indata))

    # ===== Command Thread =====
    def _process_command_audio_thread(self, audio_float32_data, language, sampling_rate, relevant_event):
        thread_id = threading.get_ident()
        if not self.main_loop_active_flag.is_set() or relevant_event.is_set():
            return

        internet_conn = is_internet_connected()
        text_transcribed = ""
        stt_processing_time = 0.0

        # Online first (Google)
        if internet_conn:
            try:
                start_t = time.time()
                audio_int16_cmd = (audio_float32_data * 32767).astype(np.int16)
                audio_data_sr_cmd = sr.AudioData(audio_int16_cmd.tobytes(), sample_rate=sampling_rate, sample_width=self.cfg.SAMPLE_WIDTH_BYTES)
                recognizer = sr.Recognizer()
                lang_code_google_cmd = {"Indonesian": "id-ID", "English": "en-US", "Japanese": "ja-JP"}.get(language, "id-ID")
                text_transcribed = recognizer.recognize_google(audio_data_sr_cmd, language=lang_code_google_cmd)
                stt_processing_time = time.time() - start_t
                if not text_transcribed:
                    raise ValueError("STT Online (Google) tidak menghasilkan teks.")
            except Exception as e:
                print(f"Thread ID {thread_id}: Gagal STT online (perintah): {e}. Menggunakan STT offline...")
                res = self.stt.transcribe(audio_float32_data, sampling_rate=sampling_rate, language=language)
                text_transcribed = res.get('text', '')
                stt_processing_time = res.get('processing_time', 0.0)
        else:
            print(f"Thread ID {thread_id}: Tidak ada koneksi internet. Menggunakan STT offline untuk perintah...")
            res = self.stt.transcribe(audio_float32_data, sampling_rate=sampling_rate, language=language)
            text_transcribed = res.get('text', '')
            stt_processing_time = res.get('processing_time', 0.0)

        if not text_transcribed.strip():
            print(f"Thread ID {thread_id}: Tidak ada teks perintah yang berhasil ditranskripsi.")
            if not relevant_event.is_set():
                self._intent_feedback("tidak relevan", language)
            return

        print(f"Thread ID {thread_id}: Transkripsi perintah: '{text_transcribed}' (Waktu STT: {stt_processing_time:.2f} dtk, Bahasa: {language})")

        # Intent
        predicted_intent = self.intent.predict(
            text_transcribed,
            is_online=internet_conn,
            gemini_url=self.cfg.GEMINI_URL,
            gemini_api_key=self.cfg.GEMINI_API_KEY
        )
        print(f"Thread ID {thread_id}: Prediksi intent final: '{predicted_intent}'")

        if not self.main_loop_active_flag.is_set():
            return

        is_winner = False
        if predicted_intent != "tidak relevan":
            if not relevant_event.is_set():
                relevant_event.set()
                is_winner = True
                print(f"Thread ID {thread_id}: Perintah relevan '{predicted_intent}' diproses. (WINNER)")
            else:
                print(f"Thread ID {thread_id}: Perintah relevan '{predicted_intent}' ditemukan, tapi sudah diproses oleh thread lain.")

        play_feedback = is_winner or (predicted_intent != "tidak relevan") or (predicted_intent == "tidak relevan" and not relevant_event.is_set())
        if play_feedback:
            self._intent_feedback(predicted_intent, language)

    # ===== Main Loop =====
    def run(self):
        if not self.initialize_system():
            print("FATAL: Gagal melakukan inisialisasi sistem. Program berhenti.")
            return

        # Determine input sample rate
        try:
            device_info = sd.query_devices(None, "input")
            SAMPLERATE = int(device_info.get("default_samplerate", self.cfg.DEFAULT_SAMPLE_RATE))
            print(f"Menggunakan samplerate: {SAMPLERATE} Hz dari perangkat input default.")
        except Exception as e:
            print(f"PERINGATAN: Gagal mendapatkan default samplerate dari SoundDevice: {e}. Menggunakan default {self.cfg.DEFAULT_SAMPLE_RATE} Hz.")
            SAMPLERATE = self.cfg.DEFAULT_SAMPLE_RATE

        vosk_thread = None
        online_check_last = time.time()
        online_check_thread = None

        try:
            while self.main_loop_active_flag.is_set():
                print("\nMenunggu wake word (Offline Vosk kontinu, Online Google STT periodik [id-ID])...")
                wake_event = threading.Event()
                detected_language = "Indonesian"

                # Reset buffer
                with self.ring.lock:
                    self.ring.buffer = bytearray(self.ring.size)
                    self.ring.write_pos = 0
                    self.ring.total_written_bytes = 0

                # Start audio stream
                callback_chunk_duration_sec = 0.2
                blocksize_callback_samples = int(SAMPLERATE * callback_chunk_duration_sec)
                if self.cfg.BUFFER_SIZE_BYTES < blocksize_callback_samples * self.cfg.SAMPLE_WIDTH_BYTES * 5:
                    print(f"PERINGATAN: BUFFER_SIZE_BYTES ({self.cfg.BUFFER_SIZE_BYTES}) mungkin terlalu kecil.")

                try:
                    self.audio_stream = sd.RawInputStream(
                        samplerate=SAMPLERATE, blocksize=blocksize_callback_samples, device=None, dtype="int16",
                        channels=1, callback=self._sd_callback
                    )
                    self.audio_stream.start()
                    print("Stream audio dimulai untuk deteksi wake word.")
                except Exception as e_stream:
                    if not self.main_loop_active_flag.is_set():
                        break
                    print(f"Error saat memulai stream audio: {e_stream}. Mencoba lagi dalam 2 detik...")
                    time.sleep(2)
                    continue

                # Start Vosk thread
                try:
                    self.wake.samplerate = SAMPLERATE
                    vosk_thread = self.wake.start_offline_thread(self.ring, wake_event, self.main_loop_active_flag)
                except Exception as e:
                    print(f"Gagal memulai detector Vosk: {e}")

                last_online_check_time = time.time()
                while not wake_event.is_set() and self.main_loop_active_flag.is_set():
                    # periodic online check
                    current = time.time()
                    if is_internet_connected(timeout=0.5) and (current - last_online_check_time > self.cfg.ONLINE_WAKE_WORD_CHECK_INTERVAL):
                        last_online_check_time = current
                        lang = self.wake.online_check_once(self.ring, SAMPLERATE)
                        if lang:
                            detected_language = lang
                            wake_event.set()
                            break
                    time.sleep(0.05)

                print("Keluar dari loop deteksi wake word (event set or shutdown).")
                if self.audio_stream and self.audio_stream.active:
                    print("Menghentikan stream audio wake word...")
                    self.audio_stream.stop()
                if self.audio_stream and not self.audio_stream.closed:
                    self.audio_stream.close()
                    self.audio_stream = None
                    print("Stream audio wake word ditutup.")

                wake_event.set()
                if vosk_thread and vosk_thread.is_alive():
                    print("Menunggu Vosk thread selesai...")
                    vosk_thread.join(timeout=2.0)

                if self.main_loop_active_flag.is_set():
                    self.state.predicted_language_from_wake_word = detected_language
                    print(f"Wake word terdeteksi! Bahasa yang digunakan: {detected_language}")
                    self._intent_feedback("wake", detected_language)

                    # Command session
                    session_event = threading.Event()
                    session_start = time.time()
                    self.active_command_threads = [t for t in self.active_command_threads if t.is_alive()]

                    while self.main_loop_active_flag.is_set():
                        if session_event.is_set():
                            print("Perintah relevan terdeteksi dan diproses. Keluar dari mode perintah sesi ini.")
                            break
                        now = time.time()
                        if now - session_start >= self.cfg.COMMAND_MODE_TIMEOUT:
                            print(f"Waktu mode perintah ({self.cfg.COMMAND_MODE_TIMEOUT} detik) habis.")
                            break
                        remaining = self.cfg.COMMAND_MODE_TIMEOUT - (now - session_start)

                        print(f"\nSilahkan ucapkan perintah (Bahasa: {detected_language}, Sisa waktu: {remaining:.0f} detik)...")
                        cmd_sr = 16000
                        audio_cmd = record_audio(duration=3, sampling_rate=cmd_sr, dynamic=True, noise_reduce=True)
                        if not self.main_loop_active_flag.is_set():
                            break
                        if is_audio_present(audio_cmd, threshold=0.001):
                            t = threading.Thread(
                                target=self._process_command_audio_thread,
                                args=(audio_cmd.copy(), detected_language, cmd_sr, session_event),
                                daemon=True
                            )
                            t.start()
                            self.active_command_threads.append(t)
                        else:
                            print("Tidak ada suara signifikan terdeteksi untuk perintah.")
                        time.sleep(0.1)

                    # Wait for any active command threads
                    remaining_threads = [t for t in self.active_command_threads if t.is_alive()]
                    if remaining_threads:
                        print(f"Menunggu {len(remaining_threads)} thread perintah yang mungkin masih berjalan...")
                        for t in remaining_threads:
                            t.join(timeout=1.5)
                    self.active_command_threads.clear()

                    if self.main_loop_active_flag.is_set():
                        print("Kembali ke mode deteksi wake word.")
                        self._intent_feedback("off", detected_language)

                elif not self.main_loop_active_flag.is_set():
                    break
                else:
                    print("Tidak ada wake word yang terdeteksi dengan jelas atau bahasa tidak ditentukan. Mencoba lagi...")
                    time.sleep(0.5)

        except KeyboardInterrupt:
            print("\nCtrl+C terdeteksi. Menghentikan program...")
        except Exception as e_main:
            print(f"\nError tak terduga di main loop: {e_main}")
            import traceback
            traceback.print_exc()
        finally:
            print("Membersihkan resource sebelum keluar...")
            self.main_loop_active_flag.clear()
            try:
                if self.audio_stream and self.audio_stream.active:
                    print("Menghentikan stream audio final...")
                    self.audio_stream.stop()
                if self.audio_stream and not self.audio_stream.closed:
                    self.audio_stream.close()
                    print("Stream audio final ditutup.")
            except Exception:
                pass

            if vosk_thread and vosk_thread.is_alive():
                print("Menunggu Vosk thread (final)...")
                vosk_thread.join(timeout=2.0)

            # Wait remaining command threads
            final_threads = [t for t in self.active_command_threads if t.is_alive()]
            if final_threads:
                print(f"Menunggu {len(final_threads)} thread perintah aktif untuk selesai (final cleanup)...")
                for t in final_threads:
                    t.join(timeout=5.0)

            # Close ESP & Feedback
            self.esp.close()
            self.feedback.close()
            self.stt.close()
            print("Program selesai.")
