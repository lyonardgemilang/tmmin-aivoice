import os
from dataclasses import dataclass
from dotenv import load_dotenv

load_dotenv()

@dataclass
class Config:
    USE_HAILO_ENCODER: bool = True
    HAILO_ENCODER_HEF: str = "/mnt/data/base-whisper-encoder-5s_h8l.hef"
    HAILO_WINDOW_SECONDS: int = 5
    DECODER_LOCAL_DIR: str | None = None  # e.g. "assets/whisper-base"

    SEND_TO_WEBSERVER: bool = True
    WEB_SERVER_URL: str = "http://10.0.0.76:5000/task"

    GEMINI_API_KEY: str | None = os.getenv("GEMINI_API_KEY")

    @property
    def GEMINI_URL(self) -> str:
        if not self.GEMINI_API_KEY:
            return ""
        return (
            "https://generativelanguage.googleapis.com/v1beta/models/"
            "gemini-1.5-flash:generateContent?key=" + self.GEMINI_API_KEY
        )

    # Audio & buffering
    BUFFER_SIZE_BYTES: int = 300000
    SAMPLE_WIDTH_BYTES: int = 2
    ONLINE_WAKE_WORD_CHECK_INTERVAL: float = 2.0
    ONLINE_WAKE_WORD_RECORD_DURATION: float = 4.0

    # Default sample rate if not queryable
    DEFAULT_SAMPLE_RATE: int = 16000

    # Command mode
    COMMAND_MODE_TIMEOUT: int = 15

    # Paths
    @property
    def BASE_DIR(self) -> str:
        try:
            return os.path.dirname(os.path.abspath(__file__))
        except Exception:
            return os.getcwd()

    @property
    def FEEDBACK_DIR(self) -> str:
        return os.path.join(self.BASE_DIR, "feedback_audio")

    @property
    def VOSK_MODELS_DIR(self) -> str:
        return os.path.join(self.BASE_DIR, "vosk_models")
