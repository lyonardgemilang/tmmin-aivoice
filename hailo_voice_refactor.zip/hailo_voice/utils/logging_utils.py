import sys

def warn(msg: str):
    print(msg, file=sys.stderr)

def info(msg: str):
    print(msg)
