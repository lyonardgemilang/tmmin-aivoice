import time
import serial
import serial.tools.list_ports

def find_esp32_port():
    ports = serial.tools.list_ports.comports()
    print("Mencari port ESP32...")
    for port in ports:
        if "ACM" in port.device.upper() or "USB" in port.device.upper() or                (port.manufacturer and "Silicon Labs" in port.manufacturer) or                (port.manufacturer and "wch.cn" in port.manufacturer) or                (port.description and "USB-SERIAL CH340" in port.description.upper()) or                (port.description and "CP210x" in port.description.upper()):
            print(f"ESP32 kemungkinan ditemukan di {port.device} ({port.description})")
            return port.device
    print("ESP32 tidak ditemukan. Pastikan terhubung dan driver terinstal.")
    return None

class ESP32Client:
    def __init__(self, using_esp: bool = False):
        self.using_esp = using_esp
        self.serial = None

    def connect(self) -> None:
        if not self.using_esp:
            return
        port = find_esp32_port()
        if not port:
            print("ESP32 tidak terdeteksi.")
            return
        try:
            self.serial = serial.Serial(port, 115200, timeout=1)
            print(f"Berhasil terhubung ke ESP32 di {port}")
            time.sleep(1.5)
        except serial.SerialException as e:
            print(f"Gagal terhubung ke ESP32: {e}.")
            self.serial = None
        except Exception as e:
            print(f"Error tak terduga saat inisialisasi ESP32: {e}")
            self.serial = None

    def send(self, command: str) -> bool:
        try:
            if not self.using_esp:
                return True
            if self.serial and self.serial.is_open:
                self.serial.write((command + "\n").encode())
                return True
            print("Port serial ESP tidak terbuka atau ESP belum diinisialisasi.")
            # Try reconnect once
            self.connect()
            if self.serial and self.serial.is_open:
                self.serial.write((command + "\n").encode())
                return True
            return False
        except serial.SerialException as e:
            print(f"Gagal mengirim ke ESP: {e}. Port mungkin terputus.")
            self.serial = None
            return False
        except Exception as e:
            print(f"Error tak terduga saat mengirim ke ESP: {e}")
            return False

    def close(self):
        try:
            if self.serial and self.serial.is_open:
                self.serial.close()
                print("Port serial ESP ditutup.")
        except Exception:
            pass
