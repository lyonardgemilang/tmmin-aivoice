import requests

class WebServerClient:
    def __init__(self, enabled: bool, url: str):
        self.enabled = enabled
        self.url = url

    def send_label(self, label: str) -> bool:
        if not self.enabled:
            print("Pengiriman ke web server dinonaktifkan.")
            return True
        try:
            params = {'label': label}
            response = requests.get(self.url, params=params, timeout=5)
            response.raise_for_status()
            print(f"Berhasil mengirim ke web server: {label}")
            return True
        except requests.exceptions.Timeout:
            print("Timeout saat mengirim ke web server.")
            return False
        except requests.exceptions.RequestException as e:
            print(f"Gagal mengirim ke web server: {e}")
            return False
