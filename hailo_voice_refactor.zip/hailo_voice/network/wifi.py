import time
from pywifi import PyWiFi, const, Profile

def connect_to_wifi(ssid: str, password: str) -> bool:
    wifi = PyWiFi()
    try:
        ifaces = wifi.interfaces()
        if not ifaces:
            print("Tidak ada antarmuka Wi-Fi yang ditemukan.")
            return False
        iface = ifaces[0]
    except Exception as e:
        print(f"Error saat mengakses antarmuka Wi-Fi: {e}")
        return False
    try:
        iface.scan()
        print("Scanning Wi-Fi...")
        time.sleep(3)
        scan_results = iface.scan_results()
    except Exception as e:
        print(f"Error saat scan Wi-Fi: {e}")
        return False
    for network in scan_results:
        if network.ssid == ssid:
            print(f"SSID ditemukan: {ssid}")
            profile = Profile()
            profile.ssid = ssid
            profile.auth = const.AUTH_ALG_OPEN
            profile.akm.append(const.AKM_TYPE_WPA2PSK)
            profile.cipher = const.CIPHER_TYPE_CCMP
            profile.key = password
            iface.remove_all_network_profiles()
            temp_profile = iface.add_network_profile(profile)
            iface.connect(temp_profile)
            print(f"Mencoba terhubung ke {ssid}...")
            for _ in range(10):
                time.sleep(1)
                if iface.status() == const.IFACE_CONNECTED:
                    print("Berhasil terhubung ke Wi-Fi!")
                    return True
            print(f"Gagal terhubung ke {ssid} setelah beberapa percobaan.")
            return False
    print(f"SSID {ssid} tidak ditemukan.")
    return False
