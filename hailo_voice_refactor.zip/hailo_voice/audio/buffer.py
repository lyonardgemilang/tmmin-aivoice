import threading

class AudioRingBuffer:
    def __init__(self, size_bytes: int):
        self.size = size_bytes
        self.buffer = bytearray(size_bytes)
        self.write_pos = 0
        self.total_written_bytes = 0
        self.lock = threading.Lock()
        self.data_available = threading.Condition(self.lock)

    def write(self, in_bytes: bytes):
        if not in_bytes:
            return
        with self.lock:
            chunk_size = len(in_bytes)
            end_space = self.size - self.write_pos
            if chunk_size > end_space:
                self.buffer[self.write_pos:] = in_bytes[:end_space]
                remaining = chunk_size - end_space
                self.buffer[:remaining] = in_bytes[end_space:]
                self.write_pos = remaining
            else:
                self.buffer[self.write_pos:self.write_pos + chunk_size] = in_bytes
                self.write_pos += chunk_size
            self.total_written_bytes += chunk_size
            self.data_available.notify_all()

    def read_latest(self, nbytes: int) -> bytes:
        with self.lock:
            available = min(self.size, self.total_written_bytes)
            n = min(nbytes, available)
            if n <= 0:
                return b""
            start_total = self.total_written_bytes - n
            start_idx = start_total % self.size
            end_idx = (start_idx + n) % self.size
            if end_idx > start_idx:
                return bytes(self.buffer[start_idx:end_idx])
            elif end_idx < start_idx:
                return bytes(self.buffer[start_idx:]) + bytes(self.buffer[:end_idx])
            else:
                # wrap full
                return bytes(self.buffer)
