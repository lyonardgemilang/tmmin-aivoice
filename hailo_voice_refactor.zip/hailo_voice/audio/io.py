import time
import numpy as np
import sounddevice as sd
import scipy.io.wavfile as wav
import noisereduce as nr
import pyaudio

from ..utils.logging_utils import warn, info

def check_microphones() -> bool:
    p = None
    try:
        p = pyaudio.PyAudio()
        info("Mikrofon yang terdeteksi:")
        found_mic = False
        default_mic_index = -1
        try:
            default_mic_info = p.get_default_input_device_info()
            default_mic_index = default_mic_info['index']
            info(f"  Default Input Device: ID {default_mic_index}, Nama: {default_mic_info['name']}")
        except IOError:
            info("  Tidak ada default input device yang terkonfigurasi di sistem.")

        for i in range(p.get_device_count()):
            device_info = p.get_device_info_by_index(i)
            if device_info.get("maxInputChannels", 0) > 0:
                name = device_info['name']
                tag = " (DEFAULT)" if i == default_mic_index else ""
                info(f"  ID: {i}, Nama: {name}{tag}")
                if i == default_mic_index or                        "ReSpeaker" in name or                        "Realtek" in name or                        "Microphone Array" in name or                        "USB PnP Sound Device" in name:
                    if not found_mic:
                         info(f"    -> Mikrofon yang sesuai/default ditemukan: {name}")
                    found_mic = True
        if not found_mic:
            warn("PERINGATAN: Tidak ada mikrofon yang dikenali (ReSpeaker, Realtek, default, dll.).")
        return found_mic
    except Exception as e:
        warn(f"Error saat memeriksa mikrofon dengan PyAudio: {e}")
        return False
    finally:
        if p:
            p.terminate()

def check_speakers() -> None:
    p = None
    try:
        p = pyaudio.PyAudio()
        info("Speaker yang terdeteksi:")
        default_speaker_index = -1
        try:
            default_speaker_info = p.get_default_output_device_info()
            default_speaker_index = default_speaker_info['index']
            info(f"  Default Output Device: ID {default_speaker_index}, Nama: {default_speaker_info['name']}")
        except IOError:
            info("  Tidak ada default output device yang terkonfigurasi di sistem.")

        for i in range(p.get_device_count()):
            device_info = p.get_device_info_by_index(i)
            if device_info.get("maxOutputChannels", 0) > 0:
                tag = " (DEFAULT)" if i == default_speaker_index else ""
                info(f"  ID: {i}, Nama: {device_info['name']}{tag}")
    except Exception as e:
        warn(f"Error saat memeriksa speaker dengan PyAudio: {e}")
    finally:
        if p:
            p.terminate()

def reduce_noise(audio, noise_sample, sr_rate, prop_decrease=0.8):
    try:
        if noise_sample.size == 0 or audio.size <= noise_sample.size:
            return audio
        return nr.reduce_noise(
            y=audio, y_noise=noise_sample, sr=sr_rate, prop_decrease=prop_decrease, stationary=True
        )
    except Exception as e:
        warn(f"Error dalam noise reduction: {e}")
        return audio

def save_audio(audio_array, filename, sampling_rate=16000):
    try:
        if audio_array.size == 0:
            info(f"Tidak ada data audio untuk disimpan ke {filename}.")
            return
        max_abs_val = np.max(np.abs(audio_array))
        if max_abs_val == 0:
            audio_normalized = np.zeros_like(audio_array, dtype=np.int16)
        else:
            audio_normalized = np.int16(audio_array * 32767 / max_abs_val)
        wav.write(filename, sampling_rate, audio_normalized)
        info(f"Audio disimpan ke {filename}")
    except Exception as e:
        warn(f"Gagal menyimpan audio ke {filename}: {e}")

def is_audio_present(audio_array_float32, threshold=0.005) -> bool:
    if audio_array_float32.size == 0:
        info("Audio array kosong, tidak ada audio terdeteksi.")
        return False
    audio_value = float(np.mean(np.abs(audio_array_float32)))
    info(f"Audio presence check value: {audio_value} (Threshold: {threshold})")
    return audio_value > threshold

def record_audio_dynamic(duration_min=3, duration_max=6, silence_duration=1, sampling_rate=16000):
    chunk_duration = 0.5
    chunk_samples = int(chunk_duration * sampling_rate)
    total_audio = []
    min_samples = int(duration_min * sampling_rate)
    max_samples = int(duration_max * sampling_rate)
    silence_threshold = 0.01
    info("Mulai merekam (dinamis)...")
    try:
        with sd.InputStream(samplerate=sampling_rate, channels=1, dtype='float32', blocksize=chunk_samples) as stream:
            start_time = time.time()
            while len(total_audio) < min_samples:
                if time.time() - start_time > duration_max + 3:
                    info("Perekaman dinamis (min_samples) melebihi batas waktu maksimum.")
                    break
                try:
                    chunk, overflowed = stream.read(chunk_samples)
                    if overflowed:
                        warn("PERINGATAN: Input audio overflow saat merekam perintah (min_samples loop).")
                    total_audio.extend(chunk.flatten())
                except sd.CallbackStop:
                    info("Perekaman dinamis (min_samples) dihentikan oleh callback.")
                    break
                except Exception as e:
                    warn(f"Error saat membaca stream (min_samples): {e}")
                    break

            last_audio_activity_time = time.time()
            while len(total_audio) < max_samples:
                current_time = time.time()
                if current_time - start_time > duration_max + 3:
                    info("Perekaman dinamis (max_samples) melebihi batas waktu maksimum.")
                    break
                if current_time - last_audio_activity_time > silence_duration + chunk_duration:
                    info("Deteksi silence (timeout aktivitas), menghentikan perekaman dinamis.")
                    break
                try:
                    chunk, overflowed = stream.read(chunk_samples)
                    if overflowed:
                        warn("PERINGATAN: Input audio overflow saat merekam perintah (max_samples loop).")
                    total_audio.extend(chunk.flatten())
                    if float(np.mean(np.abs(chunk))) >= silence_threshold:
                        last_audio_activity_time = current_time
                except sd.CallbackStop:
                    info("Perekaman dinamis (max_samples) dihentikan oleh callback.")
                    break
                except Exception as e:
                    warn(f"Error saat membaca stream (max_samples): {e}")
                    break
        info("Selesai merekam (dinamis).")
        return np.array(total_audio, dtype=np.float32)
    except sd.PortAudioError as e:
        warn(f"Error SoundDevice saat merekam (dinamis): {e}")
        return np.array([], dtype=np.float32)
    except Exception as e:
        warn(f"Error tak terduga saat merekam (dinamis): {e}")
        return np.array([], dtype=np.float32)

def record_audio(duration=2, sampling_rate=16000, noise_reduce=True, dynamic=True):
    import numpy as np
    if dynamic:
        audio_data = record_audio_dynamic(duration_min=duration, duration_max=5, silence_duration=1, sampling_rate=sampling_rate)
    else:
        info(f"Mulai merekam (durasi tetap: {duration} detik)...")
        try:
            num_samples = int(duration * sampling_rate)
            recording = sd.rec(num_samples, samplerate=sampling_rate, channels=1, dtype='float32')
            sd.wait()
            audio_data = recording.flatten()
            info("Selesai merekam (durasi tetap).")
        except sd.PortAudioError as e:
            warn(f"Error SoundDevice saat merekam (fixed): {e}")
            return np.array([], dtype=np.float32)
        except Exception as e:
            warn(f"Error tak terduga saat merekam (fixed): {e}")
            return np.array([], dtype=np.float32)

    if audio_data.size == 0:
        return np.array([], dtype=np.float32)

    if noise_reduce and audio_data.size > int(0.5 * sampling_rate):
        noise_sample_duration = min(0.5, audio_data.size / sampling_rate * 0.2)
        noise_sample_samples = int(noise_sample_duration * sampling_rate)
        if noise_sample_samples > 0:
            noise_sample = audio_data[:noise_sample_samples]
            audio_data = reduce_noise(audio_data, noise_sample, sampling_rate)
        else:
            info("Audio terlalu pendek untuk mengumpulkan sampel noise.")
    elif noise_reduce:
        info("Audio terlalu pendek untuk noise reduction, dilewati.")
    return audio_data
