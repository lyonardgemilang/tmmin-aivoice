from __future__ import annotations
import os, json, requests, torch
from transformers import AutoModelForSequenceClassification, AutoTokenizer

class IntentClassifier:
    # OFFLINE labels (trained model)
    NLP_LABELS_OFFLINE = [
        "nyalakan lampu merah", "nyalakan lampu hijau", "nyalakan lampu biru",
        "nyalakan lampu lavender", "nyalakan lampu magenta", "nyalakan lampu pink",
        "nyalakan lampu violet", "nyalakan lampu aqua", "nyalakan lampu kuning",
        "nyalakan lampu emas", "nyalakan lampu abu", "nyalakan mode senang",
        "nyalakan mode sad", "matikan lampu", "tidak relevan", "nyalakan lampu",
        "gender ke wanita", "gender ke pria", "fitur belum didukung", "turunkan kecerahan", "naikkan kecerahan"
    ]
    # ONLINE-only new labels
    NEW_ONLINE_ONLY_LABELS = [
        "buka kap mobil",
        "buka tutup bensin",
    ]
    # Combined for online
    NLP_LABELS_ONLINE = NLP_LABELS_OFFLINE + NEW_ONLINE_ONLY_LABELS

    def __init__(self, base_dir: str):
        self.base_dir = base_dir
        self.model = None
        self.tokenizer = None
        self.id_to_label = {idx: label for idx, label in enumerate(self.NLP_LABELS_OFFLINE)}
        self.exact_match = {}
        self._load_offline_model()
        self._load_exact_match()

    def _load_offline_model(self):
        try:
            nlp_model_path = os.path.join(self.base_dir, "natural_language_processing/mdeberta-intent-classification-final")
            self.tokenizer = AutoTokenizer.from_pretrained(nlp_model_path)
            self.model = AutoModelForSequenceClassification.from_pretrained(nlp_model_path).eval().to("cpu")
            print("Model NLP berhasil dimuat.")
        except Exception as e:
            print(f"Gagal memuat model NLP: {e}. Program mungkin tidak berfungsi dengan benar.")
            raise

    def _load_exact_match(self):
        try:
            path = os.path.join(self.base_dir, "natural_language_processing/final_train_data.json")
            with open(path, 'r', encoding='utf-8') as f:
                dataset_data = json.load(f)
            for item in dataset_data:
                normalized_text = item['teks'].lower().strip()
                self.exact_match[normalized_text] = item['label']
            print(f"Berhasil memuat {len(self.exact_match)} entri ke kamus exact match.")
        except FileNotFoundError:
            print("PERINGATAN: File dataset 'final_train_data.json' tidak ditemukan. Fitur exact match dinonaktifkan.")
        except Exception as e:
            print(f"Gagal memuat dataset exact match: {e}. Fitur ini akan dinonaktifkan.")

    def predict_offline(self, text_input: str) -> str:
        try:
            inputs = self.tokenizer(text_input, padding=True, truncation=True, max_length=128, return_tensors="pt").to("cpu")
            with torch.no_grad():
                outputs = self.model(**inputs)
            logits = outputs.logits
            pred_id = int(torch.argmax(logits, dim=-1).item())
            return self.id_to_label[pred_id]
        except Exception as e:
            print(f"Error saat prediksi intent offline: {e}")
            return "tidak relevan"

    def predict_online(self, text_input: str, gemini_url: str, gemini_api_key: str | None) -> str:
        if not gemini_url or not gemini_api_key:
            print("Gemini API URL atau Key tidak dikonfigurasi. Beralih ke model offline.")
            return self.predict_offline(text_input)
        prompt = (
            f"Anda adalah sebuah model untuk melakukan intent classification. "
            f"Berikut adalah list intent yang mendukung: {self.NLP_LABELS_ONLINE} "
            f"Tolong respons dengan absolut intent yang sesuai dengan kalimat yang diberikan saja, jangan tambahkan kata-kata lain. "
            f"Classification hanya boleh 1 intent saja. Jika lebih dari satu maksud terdeteksi atau tidak ada yang cocok, kembalikan "tidak relevan". "
            f"Pikirkan matang-matang maksud dari teks yang diberikan, terkadang terdapat maksud tersirat yang harus dipahami. "
            f"Jangan terpaku pada teks yang diberikan saja. Teks yang diberikan adalah: "{text_input}". "
            f"Untuk saat ini program hanya mendukung action untuk ambient light, ganti suara, buka kap mobil, buka tutup bensin, "
            f"posisi dongkrak, cara buka ban serep, cara ganti ban, dan info seatbelt pretensioner. fitur fitur lain yang berhubungan "
            f"dengan mobil tapi belum didukung, tolong klasifikasikan sebagai "fitur belum didukung". Intent yang paling sesuai adalah:"
        )
        data = {"contents": [{"parts": [{"text": prompt}]}]}
        try:
            response = requests.post(gemini_url, json=data, timeout=8)
            response.raise_for_status()
            response_json = response.json()
            if "candidates" in response_json and len(response_json["candidates"]) > 0:
                parts = response_json["candidates"][0].get("content", {}).get("parts", [])
                if parts and "text" in parts[0]:
                    predicted_intent = parts[0]["text"].strip()
                    if predicted_intent in self.NLP_LABELS_ONLINE:
                        return predicted_intent
                    for label in self.NLP_LABELS_ONLINE:
                        if label in predicted_intent:
                            return label
                    return "tidak relevan"
            return "tidak relevan"
        except requests.exceptions.Timeout:
            print("Gemini API: Timeout.")
            return "tidak relevan"
        except requests.exceptions.HTTPError as e:
            print(f"Gemini API: HTTP Error: {e}")
            return "tidak relevan"
        except requests.exceptions.RequestException as e:
            print(f"Gemini API: Request Exception: {e}")
            return "tidak relevan"
        except json.JSONDecodeError:
            print("Gemini API: Gagal parse JSON response.")
            return "tidak relevan"
        except KeyError as e:
            print(f"Gemini API: KeyError saat parsing response - {e}.")
            return "tidak relevan"
        except Exception as e:
            print(f"Gemini API: Terjadi error tak terduga: {e}")
            return "tidak relevan"

    def predict(self, text: str, is_online: bool, gemini_url: str, gemini_api_key: str | None) -> str:
        normalized_text = text.lower().strip()
        if self.exact_match:
            match = self.exact_match.get(normalized_text)
            if match:
                print(f"Intent ditemukan via exact match: '{match}'. Melewati NLP.")
                return match
        if is_online:
            return self.predict_online(text, gemini_url, gemini_api_key)
        return self.predict_offline(text)
