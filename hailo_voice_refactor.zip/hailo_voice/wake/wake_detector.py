from __future__ import annotations
import json, time, threading, numpy as np, speech_recognition as sr

from vosk import Model, KaldiRecognizer

from ..audio.buffer import AudioRingBuffer
from ..audio.io import is_audio_present
from ..utils.logging_utils import info, warn

class WakeWordDetector:
    def __init__(self, vosk_model_path_or_name: str, samplerate: int):
        try:
            if not vosk_model_path_or_name:
                raise RuntimeError("Vosk model path/name is empty")
            # Try dir path first
            try:
                self.model = Model(model_path=vosk_model_path_or_name)
            except Exception:
                self.model = Model(model_name=vosk_model_path_or_name)
            info("Model Vosk loaded successfully.")
        except Exception as e:
            raise RuntimeError(f"Gagal memuat model Vosk wake word: {e}")
        self.samplerate = samplerate

    def start_offline_thread(self, ring: AudioRingBuffer, wake_event: threading.Event, main_loop_flag: threading.Event):
        grammar = json.dumps(["hello", "oke", "hai", "toyota", "moshi", "one", "two", "three", "four", "[unk]"], ensure_ascii=False)
        recognizer = KaldiRecognizer(self.model, self.samplerate, grammar)
        t = threading.Thread(
            target=self._offline_loop, args=(ring, wake_event, main_loop_flag, recognizer), daemon=True
        )
        t.start()
        return t

    def _offline_loop(self, ring: AudioRingBuffer, wake_event, main_loop_flag, recognizer: KaldiRecognizer):
        info("Vosk wake word detector thread dimulai.")
        last_bytes_seen = 0
        while not wake_event.is_set() and main_loop_flag.is_set():
            with ring.lock:
                available = ring.total_written_bytes - last_bytes_seen
                if available <= 0:
                    ring.data_available.wait(timeout=0.1)
                    continue
                start_total = last_bytes_seen
                end_total = last_bytes_seen + available
                start_idx = start_total % ring.size
                end_idx = end_total % ring.size
                if end_idx > start_idx:
                    chunk_data = ring.buffer[start_idx:end_idx]
                elif end_idx < start_idx:
                    chunk_data = ring.buffer[start_idx:] + ring.buffer[:end_idx]
                else:
                    chunk_data = ring.buffer[:]
                last_bytes_seen += available

            if recognizer.AcceptWaveform(bytes(chunk_data)):
                result_json = recognizer.Result()
                try:
                    result = json.loads(result_json)
                except Exception:
                    result = {}
                if 'text' in result and result['text']:
                    detected_text = result['text'].lower().strip()
                    lang = None
                    if "oke toyota" in detected_text or ("oke" in detected_text and "toyota" in detected_text):
                        lang = "Indonesian"
                    elif "hello toyota" in detected_text or ("hello" in detected_text and "toyota" in detected_text):
                        lang = "English"
                    elif ("hai toyota" in detected_text or ("hai" in detected_text and "toyota" in detected_text)) or                              ("moshi moshi" in detected_text):
                        lang = "Japanese"
                    if lang and not wake_event.is_set():
                        info(f"Vosk mendeteksi wake word! Bahasa: {lang} (Teks: '{detected_text}')")
                        wake_event.set()
                        self._last_lang = lang
                        break
        info("Vosk wake word detector thread berhenti.")

    def online_check_once(self, ring: AudioRingBuffer, samplerate: int) -> str | None:
        # Take ~N seconds of most recent audio, run Google STT, look for pattern
        SAMPLE_WIDTH_BYTES = 2
        seconds = 4
        nbytes = int(seconds * samplerate * SAMPLE_WIDTH_BYTES)
        raw = ring.read_latest(nbytes)
        if not raw:
            info("Online check: Tidak ada data audio di buffer untuk dicek (0 bytes available).")
            return None
        audio_int16 = np.frombuffer(raw, dtype=np.int16)
        audio_float32 = audio_int16.astype(np.float32) / 32768.0
        info(f"Online check: Audio terkumpul {len(raw)} bytes ({len(raw)/(samplerate*SAMPLE_WIDTH_BYTES):.2f}s). Memanggil is_audio_present...")
        if not is_audio_present(audio_float32, threshold=0.004):
            info("Online check: Audio tidak signifikan terdeteksi (setelah is_audio_present).")
            return None
        try:
            audio_data_sr = sr.AudioData(raw, sample_rate=samplerate, sample_width=SAMPLE_WIDTH_BYTES)
            recognizer = sr.Recognizer()
            text = recognizer.recognize_google(audio_data_sr, language="id-ID").lower().strip()
            if text:
                info(f"Online check STT (id-ID): '{text}'")
                if "oke" in text and "toyota" in text:
                    return "Indonesian"
                if "hello" in text and "toyota" in text:
                    return "English"
                if ("hai" in text and "toyota" in text) or ("moshi" in text and "moshi" in text) or ("mosi" in text and "mosi" in text):
                    return "Japanese"
        except Exception as e:
            warn(f"Error pada saat pengecekan wake word online: {e}")
        return None

    def last_detected_language(self) -> str:
        return getattr(self, "_last_lang", "Indonesian")
