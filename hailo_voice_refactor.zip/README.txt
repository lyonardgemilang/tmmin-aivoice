Hailo Voice Assistant - OOP Refactor

How to run:
  1) Create venv and install dependencies (same as original: pyaudio, sounddevice, transformers, faster-whisper, pygame, vosk, pywifi, requests, etc.).
  2) Put your resources (vosk models, feedback_audio, NLP model folder, etc.) under hailo_voice/ as in the original layout.
  3) Set GEMINI_API_KEY in a .env file (next to where you run the app) if you want online intent classification.
  4) python -m hailo_voice.main

Notes:
  - This refactor preserves the original behavior with clearer separation of concerns.
  - All major features are retained: ring buffer, offline/online wake word, Hailo+HF decoder STT with faster-whisper fallback,
    Google STT usage, exact-match + offline/online intent classification, ESP32 + web server hooks, and audio feedback via pygame.
